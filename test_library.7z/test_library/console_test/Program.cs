﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test_library;

namespace console_test
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.Clear();  // Очистка консоли

                // Ввод радиуса круга
                Console.WriteLine("Введите радиус круга (или нажмите Esc для выхода):");
                if (Console.ReadKey(true).Key == ConsoleKey.Escape) break;  // Проверка нажатия Esc
                double radius;
                if (double.TryParse(Console.ReadLine(), out radius))
                {
                    // Создаю объект круга и вычисляю его площадь
                    shape circle = new Circle(radius);
                    Console.WriteLine($"Площадь круга с радиусом {radius}: {circle.GetArea()}");
                }
                else
                {
                    Console.WriteLine("Некорректный ввод радиуса. Попробуйте снова.");
                    Console.ReadKey();
                    continue;
                }
                
                Console.WriteLine("\nВведите сторону квадрата (или нажмите Esc для выхода):");
                if (Console.ReadKey(true).Key == ConsoleKey.Escape) break;
                double side;
                if (double.TryParse(Console.ReadLine(), out side))
                {
                    // Создаю объект квадрата и вычисляю его площадь
                    shape square = new Square(side);
                    Console.WriteLine($"Площадь квадрата со стороной {side}: {square.GetArea()}");
                }
                else
                {
                    Console.WriteLine("Некорректный ввод стороны. Попробуйте снова.");
                    Console.ReadKey();
                    continue; 
                }

                // Ввод сторон треугольника
                Console.WriteLine("\nВведите длины сторон треугольника (или нажмите Esc для выхода):");

                double sideA = ReadTriangleSide("Сторона A");
                if (sideA == -1) break;

                double sideB = ReadTriangleSide("Сторона B");
                if (sideB == -1) break;

                double sideC = ReadTriangleSide("Сторона C");
                if (sideC == -1) break;

                try
                {
                    // Создаю объект треугольника и вычисляю его площадь
                    shape triangle = new Triangle(sideA, sideB, sideC);
                    Console.WriteLine($"Площадь треугольника со сторонами {sideA}, {sideB}, {sideC}: {triangle.GetArea()}");

                    // Проверяю, является ли треугольник прямоугольным
                    if ((triangle as Triangle).IsRightAngled())
                    {
                        Console.WriteLine("Этот треугольник является прямоугольным.");
                    }
                    else
                    {
                        Console.WriteLine("Этот треугольник не является прямоугольным.");
                    }
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }

                Console.WriteLine("\nНажмите любую клавишу для продолжения или Esc для выхода...");
                while (Console.ReadKey(true).Key != ConsoleKey.Escape)
                {
                    // Ожидание нажатия клавиши, кроме Esc
                }

            } while (true); // Бесконечный цикл, который можно прервать нажатием Esc

            Console.WriteLine("Вы вышли из программы.");
        }

        // Метод для считывания стороны треугольника с проверкой нажатия Esc
        private static double ReadTriangleSide(string sideName)
        {
            Console.Write($"{sideName}: ");
            if (Console.ReadKey(true).Key == ConsoleKey.Escape) return -1;
            double side;
            if (double.TryParse(Console.ReadLine(), out side))
            {
                return side;
            }
            else
            {
                Console.WriteLine("Некорректный ввод. Попробуйте снова.");
                Console.ReadKey();
                return ReadTriangleSide(sideName);
            }
        }  
    }
}

