﻿namespace test_library
{
    public interface shape
    {
        double GetArea();
    }
}
