﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test_library
{
    public class Square: shape
    {
        private double _side;

        public Square(double side)
        {
            if (side <= 0)
                throw new ArgumentException("Сторона квадрата должна быть положительной.");
            _side = side;
        }

        public double GetArea()
        {
            return _side * _side;
        }
    }
}
