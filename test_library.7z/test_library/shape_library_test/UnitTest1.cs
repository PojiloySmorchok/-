using test_library;

namespace shape_library_test    
{   
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestCircleArea()
        {
            var circle = new Circle(5);
            Assert.AreEqual(Math.PI * 25, circle.GetArea(), 1e-10);
        }

        [TestMethod]
        public void TestTriangleArea()
        {
            var triangle = new Triangle(3, 4, 5);
            Assert.AreEqual(6, triangle.GetArea(), 1e-10);
        }

        [TestMethod]
        public void TestRightAngledTriangle()
        {
            var triangle = new Triangle(3, 4, 5);
            Assert.IsTrue(triangle.IsRightAngled());
        }
    }
}